﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ClassB
    {
        private readonly ClassA classA;
        public ClassA ClassA { get => classA; }
        public ClassB(ClassA classA)
        {
            this.classA = classA;
        }
    }
}
