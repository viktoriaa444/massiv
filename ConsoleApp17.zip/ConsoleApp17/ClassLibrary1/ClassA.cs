﻿namespace ClassLibrary1
{
    public class ClassA
    {
        private readonly string name;
        public string Name { get => name; }
        public ClassA(string name)
        {
            this.name = name;
        }
    }
}