﻿using ClassLibrary1;

while (true)
{
    Console.WriteLine("Какой класс Вы хотите создать?");
    switch (Console.ReadLine())
    {
        case "ClassA":
            Console.WriteLine(CreateClassA().Name);
            break;
        case "ClassB":
            Console.WriteLine(CreateClassB().ClassA.Name);
            break;
        default: 
            Console.WriteLine("Такого класса не существует");
            break;
    }
}

static ClassA CreateClassA()
{
    Console.Write("Введите навазние аудитории: ");
    return new ClassA(Console.ReadLine() ?? "Нет названия");
}

static ClassB CreateClassB()
{
    return new ClassB(CreateClassA());
}